let Pessoas = document.querySelector("#Pessoas");
let btCalcularIngredientes = document.querySelector("#btCalcularIngredientes");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
    let num1 = Number(Pessoas.value);

    let ovos = (num1 * 2);
    let queijo = (num1 * 50);
    
    Resultado.innerHTML = "Ingredientes Necessários:" + "<br>" + "Ovos:" + ovos + "<br>" + 
    "Gramas de Queijo:" + queijo;
}

btCalcularIngredientes.onclick = function() {
    Calcular();
}